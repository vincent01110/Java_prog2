package Chartography;

import java.util.List;

public interface Terkeptar {

    public  void hozzaad(Terkep[] terkepek);

    public java.util.List<Terkep> terkepekk(boolean csaktematikus,int nevekSzama);


}
