package Chartography;

public class TematikusTerkep extends Terkep{
    private String tema;
}
